import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class GraphEx extends PApplet {

/*
Demonstrate usage of Graph class
Author:  Darrell Harriman
Contact:  harrimand@gmail.com
*/
Graph Gr1;  //Create Graph Object
boolean pause = false;
boolean plotLine = false;
boolean gridLines = false;
boolean source = false;
boolean Axis = false;
int degAngle = 0;  //For test data

public void setup()
{
    // Window size (width, height)
  background(0);  //  Window background color
  Gr1 = new Graph(100, 200, 600, 304); //Initialize new Graph (x, y, width, height)
  Gr1.label("Graph Data");  // Graph Label Text below graph
  Gr1.bufferSize(360);  // Graph Data buffer (int size
  Gr1.yRange(0, 1023);  // Graph data values (int Minimum, int Maximum)
  Gr1.xAxis(Axis);  //  Show X Axis (boolean)
  Gr1.grid(10, 12);  // Grid Lines (int Divisions_Wide, int Divisions_high)
  Gr1.connectPoints(plotLine);  // Connect points with lines (boolean)
  Gr1.showGrid(gridLines);  //  Show Grid Lines (boolean)
  
  textAlign(CENTER);
  textSize(18);
  text("Graph Demo", width/2, 40);
  printKeys();
}

public void draw()
{
  if(source) Gr1.newData(simData1());  //Add new element of data to buffer.
  else Gr1.newData(simData2());
  Gr1.plot(); //Update graph with current data.
  delay(4);  //Control simulation speed.  Smaller is faster.
}

public int simData1()
{
  //Generate Random Data between min and max of yRange
  return PApplet.parseInt(random(0, 1023));
}

public int simData2()
{
    //Generate pseudo square wave by adding odd harmonics of sin wave.
    // sin(n) + sin(3*n)/3 + sin(5*n)/5...
    float p1 = sin(radians(degAngle));
    p1 += sin(radians(3 * degAngle))/3;
    p1 += sin(radians(5 * degAngle))/5;
    p1 += sin(radians(7 * degAngle))/7;
    degAngle = (degAngle + 2) % 360;
    //if(degAngle > 45 && degAngle < 135) return 1024;  //'Out Of Range' data test   
    return PApplet.parseInt(512 * p1 + 511); 
}

public void printKeys()
{
  println("keyboard functions:");
  println("b = blue background | g = green background | w = white background");
  println("R = red plot | G = green plot | W = white plot");
  println("r = red border | y = yellow border");
  println("p = toggle draw lines between points");
  println("x = toggle draw centered x Axis line");
  println("l = toggle draw grid lines");
  println("s = data source [ random / pseudo square wave ]");
  println("Space Bar = Pause / Resume");
}  

//Optional Keyboard functions to control appearance, select source and pause/resume
public void keyPressed()
{
  switch(key)
  {
    case ' ':
      pause = !pause;
      if(pause) noLoop();
      else loop();
      break;
    case 'b':
      Gr1.bgColor(0, 0, 64);  //  b = Blue Background
      break;      
    case 'g':
      Gr1.bgColor(0, 48, 0);  //  g = Green Background
      break;
    case 'l':
      gridLines = !gridLines;
      Gr1.showGrid(gridLines);
      break;
    case 'p':                 //  p = Connect points with lines.
      plotLine = !plotLine;
      Gr1.connectPoints(plotLine);
      break;
    case 'r':
      Gr1.borderColor(255, 0, 0);  //  r = Red Border
      break;
    case 's':                      // s = Toggle Source
      source = !source;
      break;
    case 'w':
      Gr1.bgColor(224, 224, 224);  //  w = White Background
      break;
    case 'x':                     //  x = Toggle Display X axis
      Axis = !Axis;
      Gr1.xAxis(Axis);
      break;
    case 'y':
      Gr1.borderColor(255, 255, 0);  // y = Yellow Border
      break;
    case 'G':
      Gr1.plotColor(0, 255, 0);  // G = Green Plot
      break;
    case 'R':
      Gr1.plotColor(255, 0, 0);  // R = Red Plot
      break;
    case 'W':
      Gr1.plotColor(255, 255, 255);  // W = White Plot
      break;
    default:
      break;
  }
}
    
    
    
    
    
/*
Graph class
Author:  Darrell Harriman
Contact:  harrimand@gmail.com
*/

class Graph{
  int xPos = 100, yPos = 100, w = 600, h = 400;
  int buffSize = 80, index = 0;
  int min = 0, max = 1023;
  int r = 0, g = 0, b = 0;
  int plotR = 255, plotG = 255, plotB = 255;
  int gridDivsW = 10, gridDivsH = 10;
  int data[];
  boolean connectDots = false;
  boolean xAx = false;
  boolean shGrid = false;
  boolean shYscale = true;
  PGraphics p1;  //Used to render graph background image with grid lines.
  //PGraphics scaleY; // 
  
  Graph(int x, int y, int wx, int hy)
  {
    xPos = x;
    yPos = y;
    w = wx;
    h = hy;
    pushStyle();
    stroke(0, 255, 0);
    strokeWeight(4);
    noFill();
    rectMode(CORNER);
    rect(xPos-4, yPos-4, w+8, h+8);
    fill(r, g, b);
    //fill(128);
    noStroke();
    rect(xPos, yPos, w, h);
    popStyle();
    p1 = createGraphics(w + 2, h + 3);
    this.grid(gridDivsW, gridDivsH);
    //scaleY = createGraphics(80, h+30);
    this.yScale();    
  }
  
  public void label(String name)
  {
    pushStyle();
    textAlign(CENTER);
    text(name, xPos + w/2, yPos + h + 20);
    popStyle();
  }
  
  public void bgColor(int red, int green, int blue)
  {
    r = red;
    g = green;
    b = blue;
    pushStyle();
    fill(r, g, b);
    rectMode(CORNER);
    noStroke();
    rect(xPos, yPos, w, h);
    popStyle();
    grid(gridDivsW, gridDivsH);  // Update grid background color.  
  }
  
  public void borderColor(int red, int green, int blue)
  {
    pushStyle();
    stroke(red, green, blue);
    strokeWeight(4);
    noFill();
    rectMode(CORNER);
    rect(xPos-4, yPos-4, w+8, h+8);
    popStyle();
  }
  
  public void plotColor(int red, int green, int blue)
  {
    plotR = red;
    plotG = green;
    plotB = blue;
  }
  
  public void xAxis(boolean x)
  {
    xAx = x;
    strokeWeight(1);
    this.plot();
  } 
  
  public void bufferSize(int size)
  {
    buffSize = size;
    data = new int[buffSize];
    data[0] = yPos + h/2;
  }
  
  public void yRange(int Min, int Max)
  {
    min = Min;
    max = Max;
    for(int i = 0; i < buffSize; i ++)
      data[i] = PApplet.parseInt((2 * yPos + h)/2);
  }
  
  public void connectPoints(boolean cP)
  {
    connectDots = cP;
    this.plot();
  }

  public void grid(int divsw, int divsh)
  {
    gridDivsW = divsw;
    gridDivsH = divsh;
    p1.beginDraw();
    p1.background(r, g, b);
    p1.stroke(64);
    for(int rw = w/divsw; rw < w; rw += w/divsw)
      p1.line(rw, 0, rw, h);
    for(int rh = h/divsh; rh < h; rh += h/divsh)
      p1.line(0, rh, w, rh);
    p1.endDraw();
    this.yScale();
  }
  
  public void showGrid(boolean showG)
  {
    shGrid = showG;
    this.plot();
  }
  
  public void yScale()
  {
    println(gridDivsH);
    pushMatrix();
    translate(xPos, yPos);
    pushStyle();
    fill(0);
    noStroke();
    rect(-50, -15, 40, h + 30);
    fill(255);
    textSize(14);
    textAlign(RIGHT, CENTER);
    for(int y = 0; y < gridDivsH + 1 ; y ++)
    {
      int scY = max - y * (max - min)/gridDivsH;
      text(scY, -10, y * (h / gridDivsH)-3);
      print(y + " ");
    }
    println();
    popStyle();
    popMatrix();
  }
  
/*  
    if(shYscale)
      image(scaleY, xPos + 50, yPos - 30);
    else
    {
      fill(0);
      noStroke();
      rect(xPos - 50, yPos - 30, 60, h + 30);
    }  
*/
    
  public void newData(int sample)
  {
    if(sample < min || sample > max)  // Data Out of Range ?
    {
      pushStyle();      
      textAlign(LEFT);
      fill(255, 0, 0);
      textSize(10);
      textLeading(10);
      text("RANGE\nERROR", xPos, yPos + h + 20);
      popStyle();
      return; //Ignore invalid data
    }
    pushStyle();
    rectMode(CORNER);
    fill(0);
    noStroke();
    rect(xPos, yPos + h + 10, 60, 40);  // Clear Range Error Message
    popStyle();
    int newD = PApplet.parseInt(map(sample, min, max, yPos + h, yPos));
    data[index] = newD;  // Overwrite oldest data with new data
    //print(data[index], " ");  //For Testing
    index = (index + 1) % buffSize; 
  }

  public void plot()
  {
    pushStyle();    
    if(shGrid)   //  Load background image with grid lines.
      image(p1, xPos - 1, yPos -1);
    else
    {
    fill(r, g, b);
    rectMode(CORNER);
    noStroke();
    rect(xPos - 1, yPos-1, w+2, h+3);
    }
 
    int xP = 0;
    int x = PApplet.parseInt(map(xP, 0, buffSize, xPos, xPos + w));
    int y = data[index];
    //print(y, " ");  //For Testing
    int xLast = x;
    int yLast = y;
    stroke(plotR, plotG, plotB);    
    
    for(xP = 0; xP < buffSize; xP ++)
    {
      point(x, y);
      x = PApplet.parseInt(map(xP, 0, buffSize, xPos, xPos + w));
      y = data[(xP + index) % buffSize];
      //print(y, " ");
      if(connectDots)
      {
        line(xLast, yLast, x, y);
        xLast = x;
        yLast = y;
      }
    }
    if(xAx)
     line(xPos - 1, (2 * yPos + h)/2, xPos + w, (2 * yPos + h)/2);  
    popStyle();
  }
}
  public void settings() {  size(800, 600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "GraphEx" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
